#!/bin/bash
# ============================================================
#  StockPro – Publicar no GitHub
#  Corre na pasta raiz do projeto: bash publicar_github.sh
# ============================================================

GH_USER="condessa"
GH_REPO="stockpro"
GH_URL="https://${GH_USER}@github.com/${GH_USER}/${GH_REPO}.git"

echo "============================================"
echo "  StockPro – Publicar no GitHub"
echo "============================================"

# 1. Criar repositório via API
echo ""
echo "[1/4] A criar repositório no GitHub..."
HTTP=$(curl -s -o /tmp/gh_resp.json -w "%{http_code}" \
  -X POST https://api.github.com/user/repos \
  -u "${GH_USER}:$(cat /tmp/.ghpw 2>/dev/null || read -sp 'Password GitHub: ' PW; echo $PW | tee /tmp/.ghpw; echo)" \
  -H "Content-Type: application/json" \
  -d "{\"name\":\"${GH_REPO}\",\"description\":\"StockPro - Gestão de Stocks by HCsoftware\",\"private\":false}")

if echo "$HTTP" | grep -q "^201"; then
    echo "  ✔ Repositório criado: github.com/${GH_USER}/${GH_REPO}"
elif echo "$HTTP" | grep -q "^422"; then
    echo "  ℹ Repositório já existe, a continuar..."
else
    echo "  ERRO HTTP $HTTP"
    cat /tmp/gh_resp.json
    rm -f /tmp/.ghpw; exit 1
fi

# 2. Criar version.txt
echo "1.0.0" > version.txt

# 3. Inicializar git e fazer push
echo ""
echo "[2/4] A configurar git..."
git init -q
git config user.email "${GH_USER}@github.com"
git config user.name "HCsoftware"

# Criar .gitignore
cat > .gitignore << 'EOF'
__pycache__/
*.pyc
*.pyo
config.json
dist/
*.deb
.ghpw
EOF

echo ""
echo "[3/4] A adicionar ficheiros..."
git add .
git commit -q -m "StockPro v1.0.0 — lançamento inicial"

echo ""
echo "[4/4] A publicar no GitHub..."
# Usar token/password para push
git remote remove origin 2>/dev/null || true
git remote add origin "https://${GH_USER}:$(cat /tmp/.ghpw)@github.com/${GH_USER}/${GH_REPO}.git"
git branch -M main
git push -u origin main

rm -f /tmp/.ghpw

echo ""
echo "============================================"
echo "  ✔ Projeto publicado com sucesso!"
echo "  https://github.com/${GH_USER}/${GH_REPO}"
echo ""
echo "  Para futuras atualizações:"
echo "  1. Altera version.py e version.txt"
echo "  2. bash publicar_github.sh"
echo "============================================"
