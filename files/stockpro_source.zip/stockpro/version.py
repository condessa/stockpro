"""StockPro – Versão da aplicação"""

VERSION       = "1.0.0"
VERSION_TUPLE = (1, 0, 0)
RELEASE_DATE  = "2026-03-05"
AUTHOR        = "HCsoftware"

# URL do ficheiro de versão remoto para verificar atualizações
# Deve conter apenas o número de versão ex: 1.0.1
UPDATE_CHECK_URL = "https://raw.githubusercontent.com/hcsoftware/stockpro/main/version.txt"
